<?php
/**
 * PHPMailer language file.  
 * Slovak Version
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'Mus�te zada� aspo� jednu ' .
                                     'emailov� adresu pr�jemcu.';
$PHPMAILER_LANG["mailer_not_supported"] = ' mailov� klient nie je podporovan�.';
$PHPMAILER_LANG["execute"] = 'Ned� sa vykona�: ';
$PHPMAILER_LANG["instantiate"] = 'Ned� sa vykona� instancia emailovej funkcie.';
$PHPMAILER_LANG["authenticate"] = 'SMTP Chyba: Chyba autentik�cie.';
$PHPMAILER_LANG["from_failed"] = 'Nasleduj�ca adresa je nespr�vna: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Chyba: Adresy pr�jemcov ' .
                                       's� nespr�vn� ' .
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP Chyba: D�ta neboli prijat�';
$PHPMAILER_LANG["connect_host"] = 'SMTP Chyba: Ned� sa nadviaza� spojenie s ' .
                                  ' SMTP serverom.';
$PHPMAILER_LANG["file_access"] = 'S�bor nen�jden�: ';
$PHPMAILER_LANG["file_open"] = 'Chyba s�boru: Ned� sa otvori� s�bor pre ��tanie: ';
$PHPMAILER_LANG["encoding"] = 'Nezn�me k�dovanie: ';
?>